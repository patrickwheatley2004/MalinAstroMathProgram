﻿using System;

namespace AstroMaths
{
    public class Maths
    {
        // This function gets the user to Input the Observed Wavelength and the Rest Wavelength and returns Star Velocity using the Doppler shift.
        // "oWL" is Observed Wavelength, "rWL" is Rest Wave Length".
        // "c" is the Speed of Light in metres per second. 
        // "change" is the change in wavelength.
        // "v" is the Velocity which gets rounded and returned.
        public double StarVelocity(double oWL, double rWL)
        {
            if (rWL != 0)
            {
                double c = 299792458;
                double change = oWL - rWL;
                double v = c * (change / rWL);
                return Math.Round(v);
            }
            else
            {
                return -1;
            }

        }

        // This function gets the user to input Celcius and converts Celcius to Kelvin.
        // Returns Kelvin.
        public double Kelvin(double celcius)
        {
            if (celcius >= -273 && celcius <= 10000)
            {
                return celcius + 273;
            }
            else
            {
                return -1;
            }
        }
        // This function gets the user to input the Arseconds angle and returns the Star Distance.
        // "Angle" is the Arseconds angle.
        // "distance" is the value that gets rounded and returned in parsecs.
        public double StarDistance(double angle)
        {
            if (angle > 0)
            {
                double distance = 1 / angle;
                return Math.Round(distance, 2);
            }
            else
            {
                return -1;
            }

        }
        // This function gets the user to input the mass of a blackhole and returns the Schwarzchild radius / distance from the centre of a blackhole to the Event Horizon.
        // "gravity" is the gravity constant.
        // "c" is the Speed of Light in metres per second.
        // "R" is the Schwarzchild radius / distance from the centre of a blackhole to the Event Horizon which gets rounded.

        public double EventHorizon(double blackholeMass)
        {
            if (blackholeMass > 0)
            {
                double gravity = 6.674 * (Math.Pow(10, -11));
                int c = 299792458;
                double R = (2 * gravity * blackholeMass) / Math.Pow(c, 2);
                return Math.Round(R);
            }
            else
            {
                return -1;
            }

        }
    }
}
