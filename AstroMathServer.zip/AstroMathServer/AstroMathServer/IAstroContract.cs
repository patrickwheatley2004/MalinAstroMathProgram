﻿using System;
using System.ServiceModel;
using AstroMaths;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AstroMathServer
{
    [ServiceContract]
    public interface IAstroContract
    {
        [OperationContract]
        double StarVelocity(double oWL, double rWL);

        [OperationContract]
        double StarDistance(double angle);

        [OperationContract]
        double Kelvin(double celcius);

        [OperationContract]
        double EventHorizon(double mass);
    }
}
