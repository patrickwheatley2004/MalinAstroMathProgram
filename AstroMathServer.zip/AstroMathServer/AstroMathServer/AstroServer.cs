﻿using System;
using AstroMaths;
using System.ServiceModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AstroMathServer
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    internal class AstroServer : IAstroContract
    {
        Maths math = new Maths();
        public double StarVelocity(double oWL, double rWL)
        {
            return math.StarVelocity(oWL, rWL);
        }

        public double StarDistance(double angle)
        {
            return math.StarDistance(angle);
        }

        public double Kelvin(double celcius)
        {
            return math.Kelvin(celcius);
        }

        public double EventHorizon(double mass)
        {
            return math.EventHorizon(mass);
        }

    }
}
